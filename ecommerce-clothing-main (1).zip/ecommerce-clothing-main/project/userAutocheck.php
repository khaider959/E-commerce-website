<?php
if(!$_SESSION['auth'])
{
    header("Location: homepage.php");
}

?>
