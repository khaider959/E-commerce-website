<?php
 session_start();
 session_unset();
 header("Location: sm_loginPage.php");
?>